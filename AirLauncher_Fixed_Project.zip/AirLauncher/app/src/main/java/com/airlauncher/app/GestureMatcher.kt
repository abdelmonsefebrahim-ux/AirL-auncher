package com.airlauncher.app

import android.graphics.PointF
import kotlin.math.hypot

object GestureMatcher {
    
    fun resample(points: List<TrajectoryPoint>, targetCount: Int = 30): List<PointF> {
        if (points.size < 2) return List(targetCount) { PointF(0f, 0f) }
        var totalLength = 0f
        for (i in 0 until points.size - 1) {
            totalLength += hypot(points[i+1].x - points[i].x, points[i+1].y - points[i].y)
        }
        val interval = totalLength / (targetCount - 1)
        val resampled = mutableListOf<PointF>()
        resampled.add(PointF(points.first().x, points.first().y))
        
        var accumDistance = 0f
        var i = 0
        while (resampled.size < targetCount && i < points.size - 1) {
            val p1 = points[i]
            val p2 = points[i+1]
            val segmentLength = hypot(p2.x - p1.x, p2.y - p1.y)
            if (accumDistance + segmentLength >= interval) {
                val ratio = (interval - accumDistance) / segmentLength
                val nx = p1.x + ratio * (p2.x - p1.x)
                val ny = p1.y + ratio * (p2.y - p1.y)
                resampled.add(PointF(nx, ny))
                accumDistance = 0f
            } else {
                accumDistance += segmentLength
                i++
            }
        }
        while (resampled.size < targetCount) {
            resampled.add(PointF(points.last().x, points.last().y))
        }
        return resampled
    }

    fun normalize(points: List<PointF>): List<PointF> {
        if (points.isEmpty()) return points
        var minX = Float.MAX_VALUE
        var maxX = Float.MIN_VALUE
        var minY = Float.MAX_VALUE
        var maxY = Float.MIN_VALUE
        for (p in points) {
            if (p.x < minX) minX = p.x
            if (p.x > maxX) maxX = p.x
            if (p.y < minY) minY = p.y
            if (p.y > maxY) maxY = p.y
        }
        val width = maxX - minX
        val height = maxY - minY
        val maxDim = maxOf(width, height, 0.001f)
        return points.map { PointF((it.x - minX) / maxDim, (it.y - minY) / maxDim) }
    }

    fun computeDtwSimilarity(pathA: List<PointF>, pathB: List<PointF>): Float {
        val n = pathA.size
        val m = pathB.size
        if (n == 0 || m == 0) return 0f
        val dtw = Array(n) { FloatArray(m) }
        for (i in 0 until n) {
            for (j in 0 until m) {
                val dist = hypot(pathA[i].x - pathB[j].x, pathA[i].y - pathB[j].y)
                val cost1 = if (i > 0) dtw[i-1][j] else Float.MAX_VALUE
                val cost2 = if (j > 0) dtw[i][j-1] else Float.MAX_VALUE
                val cost3 = if (i > 0 && j > 0) dtw[i-1][j-1] else 0f
                val minPrev = if (i == 0 && j == 0) 0f else minOf(cost1, cost2, cost3)
                dtw[i][j] = dist + minPrev
            }
        }
        val maxPossibleDistance = hypot(1f, 1f) * maxOf(n, m)
        val finalCost = dtw[n-1][m-1]
        return (1f - (finalCost / maxPossibleDistance)).coerceIn(0f, 1f)
    }
}
