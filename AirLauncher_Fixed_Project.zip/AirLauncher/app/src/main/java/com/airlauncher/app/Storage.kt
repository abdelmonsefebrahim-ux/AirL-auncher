package com.airlauncher.app

import android.content.Context

object Storage {
    private val templates = mutableListOf<GestureTemplate>()

    fun saveTemplate(template: GestureTemplate) {
        templates.add(template)
    }

    fun getAllTemplates(): List<GestureTemplate> {
        return templates
    }
    
    fun deleteTemplate(id: String) {
        templates.removeAll { it.id == id }
    }
}
