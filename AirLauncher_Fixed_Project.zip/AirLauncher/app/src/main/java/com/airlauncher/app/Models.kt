package com.airlauncher.app

data class TrajectoryPoint(
    val x: Float,
    val y: Float,
    val timestamp: Long
)

data class GestureTemplate(
    val id: String,
    val name: String,
    val packageName: String,
    val points: List<TrajectoryPoint>
)

data class AppMetaData(
    val label: String,
    val packageName: String
)
