package com.airlauncher.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

object CameraRuntime {
    fun getInstalledApps(context: Context): List<AppMetaData> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val list = mutableListOf<AppMetaData>()
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        for (info in resolveInfos) {
            val label = info.loadLabel(pm).toString()
            val pack = info.activityInfo.packageName
            list.add(AppMetaData(label, pack))
        }
        return list.sortedBy { it.label }
    }

    fun launchApp(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }
}
