package com.airlauncher.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.PointF
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasCameraPermission = it }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            launcher.launch(Manifest.permission.CAMERA)
        }
    }

    var selectedApp by remember { mutableStateOf<AppMetaData?>(null) }
    var statusText by remember { mutableStateOf("Status: Idle") }
    val pointsBuffer = remember { mutableStateListOf<TrajectoryPoint>() }
    var trainingSamples = remember { mutableStateListOf<List<PointF>>() }
    var isTrainingMode by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Air Launcher Fix Builder") }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (hasCameraPermission) {
                Box(modifier = Modifier.fillMaxWidth().height(200.dp).background(Color.Black)) {
                    CameraView(
                        onFingertipTracked = { x, y, ts ->
                            pointsBuffer.add(TrajectoryPoint(x, y, ts))
                            statusText = "Tracking: [${pointsBuffer.size} pts]"
                            
                            if (!isTrainingMode && pointsBuffer.size > 20) {
                                val currentResampled = GestureMatcher.resample(pointsBuffer.toList())
                                val currentNorm = GestureMatcher.normalize(currentResampled)
                                for (template in Storage.getAllTemplates()) {
                                    val tResampled = GestureMatcher.resample(template.points)
                                    val tNorm = GestureMatcher.normalize(tResampled)
                                    val sim = GestureMatcher.computeDtwSimilarity(currentNorm, tNorm)
                                    if (sim > 0.80f) {
                                        statusText = "MATCH! Launching ${template.name}"
                                        CameraRuntime.launchApp(context, template.packageName)
                                        pointsBuffer.clear()
                                        break
                                    }
                                }
                            }
                        },
                        onTrackingLost = {
                            if (pointsBuffer.isNotEmpty() && !isTrainingMode) {
                                pointsBuffer.clear()
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(text = statusText, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(10.dp))

            if (selectedApp != null) {
                Text("Selected: ${selectedApp!!.label}")
                Row {
                    Button(onClick = {
                        isTrainingMode = true
                        pointsBuffer.clear()
                        trainingSamples.clear()
                        statusText = "Perform Gesture - Attempt 1/3"
                    }) { Text("Start Training") }
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    if (isTrainingMode) {
                        Button(onClick = {
                            if (pointsBuffer.size < 10) {
                                Toast.makeText(context, "Too short! Draw more.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val resampled = GestureMatcher.resample(pointsBuffer.toList())
                            val norm = GestureMatcher.normalize(resampled)
                            trainingSamples.add(norm)
                            pointsBuffer.clear()

                            if (trainingSamples.size >= 3) {
                                val sim1 = GestureMatcher.computeDtwSimilarity(trainingSamples[0], trainingSamples[1])
                                val sim2 = GestureMatcher.computeDtwSimilarity(trainingSamples[1], trainingSamples[2])
                                if (sim1 > 0.70f && sim2 > 0.70f) {
                                    Storage.saveTemplate(GestureTemplate(
                                        id = System.currentTimeMillis().toString(),
                                        name = selectedApp!!.label,
                                        packageName = selectedApp!!.packageName,
                                        points = pointsBuffer.toList()
                                    ))
                                    statusText = "Success! Gesture saved."
                                } else {
                                    statusText = "Failed: Inconsistent attempts. Try again."
                                }
                                isTrainingMode = false
                            } else {
                                statusText = "Perform Gesture - Attempt ${trainingSamples.size + 1}/3"
                            }
                        }) { Text("Save Attempt") }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text("Select App to map:", style = MaterialTheme.typography.titleSmall)
            
            val apps = remember { CameraRuntime.getInstalledApps(context) }
            LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
                items(apps) { app ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        onClick = { selectedApp = app }
                    ) {
                        Text(app.label, modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun CameraView(onFingertipTracked: (Float, Float, Long) -> Unit, onTrackingLost: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    LaunchedEffect(Unit) {
        val cameraProvider = ProcessCameraProvider.getInstance(context).get()
        val preview = Preview.Builder().build().apply { setSurfaceProvider(previewView.surfaceProvider) }
        val imageAnalysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build().apply {
                setAnalyzer(cameraExecutor, HandTracker(context, onFingertipTracked, onTrackingLost))
            }
        try {
            cameraProvider.unbindAll()
            cameraProvider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_FRONT_CAMERA, preview, imageAnalysis)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
}
